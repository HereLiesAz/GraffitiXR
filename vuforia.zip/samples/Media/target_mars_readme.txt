/*============================================================================
Copyright (c) 2024 PTC Inc. and/or Its Subsidiary Companies.
All rights reserved.
=============================================================================*/

Vuforia Engine Augmented Reality SDK
------------------------------------
To print a 3D model of the Model Target, go to https://library.vuforia.com/articles/Solution/printing-assembling-the-viking-lander.html
